"""Quick self-test: tells you exactly what is wrong before the server starts."""
import asyncio
import socket
import sys
import warnings

warnings.filterwarnings("ignore")
OK, BAD, WARN = "[ OK ]", "[FAIL]", "[WARN]"

print(f"Python {sys.version.split()[0]}")
if sys.version_info >= (3, 14):
    print(f"{WARN} Python 3.14+ is very new; if installs failed, install Python 3.12 from python.org")

try:
    from app.config import ENV_FILE, get_settings
    s = get_settings()
    print(f"{OK} .env loaded ({ENV_FILE})")
except Exception as e:  # noqa: BLE001
    print(f"{BAD} Could not load backend/.env -> {e}")
    sys.exit(0)

# ── Database ────────────────────────────────────────────
try:
    from sqlalchemy.engine import make_url
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine

    url = make_url(s.database_url)
    infos = socket.getaddrinfo(url.host, url.port or 5432, type=socket.SOCK_STREAM)
    fams = {i[0] for i in infos}
    if socket.AF_INET not in fams:
        print(f"{WARN} {url.host} only has an IPv6 address. Most home networks can't reach it.")
        print("       Fix: Supabase -> Connect -> 'Session pooler' string -> DATABASE_URL in backend/.env")

    async def probe():
        eng = create_async_engine(s.database_url, connect_args={"statement_cache_size": 0, "timeout": 10})
        async with eng.connect() as c:
            await c.execute(text("select 1"))
        await eng.dispose()

    asyncio.run(asyncio.wait_for(probe(), 20))
    print(f"{OK} Database connection works")
except Exception as e:  # noqa: BLE001
    print(f"{BAD} Database: {type(e).__name__}: {str(e)[:200]}")
    print("       Fix: use the Supabase 'Session pooler' connection string in DATABASE_URL (see HOW-TO-RUN.md)")

# ── Supabase Auth ───────────────────────────────────────
try:
    import httpx
    r = httpx.get(f"{s.supabase_url}/auth/v1/health", headers={"apikey": s.supabase_anon_key}, timeout=10)
    print(f"{OK if r.status_code == 200 else BAD} Supabase Auth reachable (HTTP {r.status_code})")
except Exception as e:  # noqa: BLE001
    print(f"{BAD} Supabase Auth: {type(e).__name__}: {str(e)[:150]}")

# ── Gemini ──────────────────────────────────────────────
try:
    import google.generativeai as genai
    genai.configure(api_key=s.gemini_api_key)
    out = genai.GenerativeModel(s.gemini_model).generate_content("Reply with the single word OK", request_options={"timeout": 20})
    print(f"{OK} Gemini works ({out.text.strip()[:20]})")
except Exception as e:  # noqa: BLE001
    print(f"{BAD} Gemini: {str(e)[:200]}")
    print("       Fix: create a key at https://aistudio.google.com/app/apikey and set GEMINI_API_KEY")
print()
