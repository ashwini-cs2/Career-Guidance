import logging
import traceback
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import get_settings
from app.database import engine
from app.models import Base  # noqa: F401 – ensures all models are registered
from app.routers import auth, career, chat, profile, resume, roadmap, skills

settings = get_settings()
log = logging.getLogger("uvicorn.error")


# ── Lifespan (startup / shutdown) ─────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create tables on startup (use Alembic for production migrations)
    # Don't crash the whole server if the DB is unreachable — keep the API up
    # so the frontend can reach it, and print a clear message instead.
    try:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        log.info("Database connection OK")
    except Exception as exc:  # noqa: BLE001
        log.error(
            "\n\n*** COULD NOT CONNECT TO THE DATABASE ***\n%s: %s\n"
            "Check DATABASE_URL in backend/.env (use the Supabase 'Session pooler' "
            "connection string if your network has no IPv6).\n",
            type(exc).__name__, exc,
        )
    yield
    await engine.dispose()


# ── App factory ───────────────────────────────────────────────────────────────
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="""
## AI-Powered Career Advisor API

A comprehensive FastAPI backend that powers personalised career guidance using **Google Gemini 2.5 Flash**.

### Features
- 🔐 **Authentication** — Supabase JWT-based auth
- 👤 **Student Profile** — Manage degree, skills, interests & goals
- 🎯 **Career Recommendations** — AI-generated role suggestions with salary insights
- 📄 **Resume Analyzer** — ATS scoring, skill extraction, improvement tips
- 🔍 **Skill Gap Analysis** — Compare current vs required skills for any role
- 🗺️ **Learning Roadmap** — Month-by-month plan with projects & certifications
- 💬 **AI Career Chatbot** — Context-aware conversation with full history
    """,
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# ── CORS ──────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Global exception handlers ─────────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    traceback.print_exception(type(exc), exc, exc.__traceback__)
    headers = {}
    origin = request.headers.get("origin")
    # 500 responses bypass CORSMiddleware, and without these headers the browser
    # reports "could not reach server" instead of the real error.
    if origin and origin in settings.allowed_origins:
        headers = {
            "Access-Control-Allow-Origin": origin,
            "Access-Control-Allow-Credentials": "true",
        }
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "Server error: check the backend terminal for details."},
        headers=headers,
    )


# ── Routers ───────────────────────────────────────────────────────────────────
PREFIX = "/api/v1"

app.include_router(auth.router, prefix=PREFIX)
app.include_router(profile.router, prefix=PREFIX)
app.include_router(career.router, prefix=PREFIX)
app.include_router(resume.router, prefix=PREFIX)
app.include_router(skills.router, prefix=PREFIX)
app.include_router(roadmap.router, prefix=PREFIX)
app.include_router(chat.router, prefix=PREFIX)


# ── Health check ──────────────────────────────────────────────────────────────
@app.get("/health", tags=["Health"], summary="Health check")
async def health():
    return {
        "status": "healthy",
        "app": settings.app_name,
        "version": settings.app_version,
    }


@app.get("/", tags=["Root"], include_in_schema=False)
async def root():
    return {"message": f"Welcome to {settings.app_name} API", "docs": "/docs"}
