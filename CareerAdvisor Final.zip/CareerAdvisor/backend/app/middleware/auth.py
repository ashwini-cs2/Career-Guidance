import asyncio

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_db
from app.models import UserProfile
from app.services.auth import get_supabase_client

settings = get_settings()
bearer_scheme = HTTPBearer()


def _verify_with_supabase(token: str) -> dict | None:
    """Fallback: ask Supabase to validate the token (works for any signing key type)."""
    try:
        res = get_supabase_client().auth.get_user(token)
        if res and res.user:
            return {
                "sub": res.user.id,
                "email": res.user.email,
                "user_metadata": res.user.user_metadata or {},
            }
    except Exception as exc:  # noqa: BLE001
        print("SUPABASE TOKEN CHECK FAILED:", str(exc))
    return None


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> UserProfile:
    token = credentials.credentials
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired token",
        headers={"WWW-Authenticate": "Bearer"},
    )

    payload: dict | None = None
    try:
        # Fast path: projects that still sign tokens with the legacy HS256 secret
        payload = jwt.decode(
            token,
            settings.supabase_jwt_secret,
            algorithms=["HS256"],
            options={"verify_aud": False},
        )
    except JWTError:
        # Newer Supabase projects sign with asymmetric keys — let Supabase verify it
        payload = await asyncio.to_thread(_verify_with_supabase, token)

    user_id = payload.get("sub") if payload else None
    if not user_id:
        raise credentials_exception

    result = await db.execute(
        select(UserProfile).where(UserProfile.user_id == user_id)
    )
    profile = result.scalar_one_or_none()

    if profile is None:
        # Valid Supabase user but no local profile row yet — create it.
        email = payload.get("email")
        if not email:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User profile not found. Please register again.",
            )
        meta = payload.get("user_metadata") or {}
        profile = UserProfile(
            user_id=user_id,
            email=email,
            full_name=meta.get("full_name") or email.split("@")[0],
        )
        db.add(profile)
        await db.flush()

    return profile
