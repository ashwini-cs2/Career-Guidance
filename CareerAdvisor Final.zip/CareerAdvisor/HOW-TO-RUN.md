# Running PathAI (both parts must be running)

1. Double-click `start-backend.bat` -> read the "Self-test" lines; every line should say [ OK ].
   Check http://localhost:8000/health in the browser: it must show {"status":"healthy",...}.
2. Double-click `start-frontend.bat` -> open http://localhost:5173
3. Click "Sign up free" and create an account (the old fake login is gone; sign-in is now real).

## If the backend shows "COULD NOT CONNECT TO THE DATABASE"
Your DATABASE_URL uses the Supabase *direct* host (db.<ref>.supabase.co), which is IPv6-only on
most networks/ISPs. In Supabase: Project -> Connect -> "Session pooler", copy that string, and put it
in backend/.env as:
  DATABASE_URL=postgresql+asyncpg://postgres.<ref>:<password>@aws-0-<region>.pooler.supabase.com:5432/postgres
(keep the `postgresql+asyncpg://` prefix; URL-encode special characters in the password).

## If AI features say "AI service error: ... API key not valid"
Create a key at https://aistudio.google.com/app/apikey (starts with "AIza") and set GEMINI_API_KEY in backend/.env.

Never share backend/.env — it holds your secret keys.
